local push = require("Scripts/Plugins/push")
local show = require("Scripts/Plugins/show")

clickedCard = nil

local mousePosition = {}
  mousePosition.x = nil
  mousePosition.y = nil

local input = {}

function input.update(dt)
  if sceneType == "settings" then
    -- update sliders
    volumeSlider.slider:update(mousePosition.x, mousePosition.y)
    sfxSlider.slider:update(mousePosition.x, mousePosition.y)
  end
end

function input.mousemoved(x, y, dx, dy)
  -- get mouse position considering screen resizing
  mousePosition.x, mousePosition.y = push:toGame(x, y)

-- check if mouse is over a button and highlight it acordingly (change the flag highlighted)
-- this applies to all buttons
  if sceneType == "mainMenu" then
    if input.checkIfMouseOver(playButton) then
      playButton.highlighted = true
    else
      playButton.highlighted = false
    end

    if input.checkIfMouseOver(settingsButton) then
      settingsButton.highlighted = true
    else
      settingsButton.highlighted = false
    end

    if input.checkIfMouseOver(gameSetupButton) then
      gameSetupButton.highlighted = true
    else
      gameSetupButton.highlighted = false
    end

    if input.checkIfMouseOver(quitButton) then
      quitButton.highlighted = true
    else
      quitButton.highlighted = false
    end
  end

  if sceneType == "settings" then
    if input.checkIfMouseOver(backButton) then
      backButton.highlighted = true
    else
      backButton.highlighted = false
    end
  end

  if sceneType == "gameSetup" then
    if input.checkIfMouseOver(onePlayerButton) then
      onePlayerButton.highlighted = true
    else
      onePlayerButton.highlighted = false
    end

    if input.checkIfMouseOver(twoPlayerButton) then
      twoPlayerButton.highlighted = true
    else
      twoPlayerButton.highlighted = false
    end

    if input.checkIfMouseOver(threePlayerButton) then
      threePlayerButton.highlighted = true
    else
      threePlayerButton.highlighted = false
    end

    if input.checkIfMouseOver(fourPlayerButton) then
      fourPlayerButton.highlighted = true
    else
      fourPlayerButton.highlighted = false
    end

    if input.checkIfMouseOver(numberOfColumnsPlusRect) then
      numberOfColumnsPlusRect.highlighted = true
    else
      numberOfColumnsPlusRect.highlighted = false
    end

    if input.checkIfMouseOver(numberOfColumnsMinusRect) then
      numberOfColumnsMinusRect.highlighted = true
    else
      numberOfColumnsMinusRect.highlighted = false
    end

    if input.checkIfMouseOver(numberOfRowsPlusRect) then
      numberOfRowsPlusRect.highlighted = true
    else
      numberOfRowsPlusRect.highlighted = false
    end

    if input.checkIfMouseOver(numberOfRowsMinusRect) then
      numberOfRowsMinusRect.highlighted = true
    else
      numberOfRowsMinusRect.highlighted = false
    end

    if input.checkIfMouseOver(backButton) then
      backButton.highlighted = true
    else
      backButton.highlighted = false
    end
  end

  if sceneType == "gameplay" then
    if gameState == "playing" then
      -- check if mouse is over a card and highlight it acordingly (change the flag highlighted)
      for i,crd in ipairs(createdCards) do
        if crd.matched == false and crd.flipCard == false then
          if input.checkIfMouseOver(crd) then
            crd.highlighted = true
          else
            crd.highlighted = false
          end
        end
      end
      if input.checkIfMouseOver(inGameMainMenuButton) then
        inGameMainMenuButton.highlighted = true
      else
        inGameMainMenuButton.highlighted = false
      end
    end

    if gameState == "gameWon" then
      if input.checkIfMouseOver(tryAgainButton) then
        tryAgainButton.highlighted = true
      else
        tryAgainButton.highlighted = false
      end

      if input.checkIfMouseOver(mainMenuButton) then
        mainMenuButton.highlighted = true
      else
        mainMenuButton.highlighted = false
      end
    end

    if gameState == "gameLost" then
      if input.checkIfMouseOver(tryAgainButton) then
        tryAgainButton.highlighted = true
      else
        tryAgainButton.highlighted = false
      end

      if input.checkIfMouseOver(mainMenuButton) then
        mainMenuButton.highlighted = true
      else
        mainMenuButton.highlighted = false
      end
    end
  end
end

function input.mousepressed(x, y, button, isTouch)
  -- check if left mouse button is clicked
  if button == 1 then
    -- if so, check if mouse is over a button (check its highlighted flag), and change its pressed flag acordingly
    -- this applies to all buttons
    if sceneType == "mainMenu" then
      if playButton.highlighted then
        playButton.highlighted = false
        playButton.pressed = true
      end

      if settingsButton.highlighted then
        settingsButton.highlighted = false
        settingsButton.pressed = true
      end

      if gameSetupButton.highlighted then
        gameSetupButton.highlighted = false
        gameSetupButton.pressed = true
      end

      if quitButton.highlighted then
        quitButton.pressed = true
      end
    end

    if sceneType == "settings" then
      if backButton.highlighted then
        backButton.highlighted = false
        backButton.pressed = true
      end
    end

    if sceneType == "gameSetup" then
      if onePlayerButton.highlighted then
        onePlayerButton.pressed = true
      end

      if twoPlayerButton.highlighted then
        twoPlayerButton.pressed = true
      end

      if threePlayerButton.highlighted then
        threePlayerButton.pressed = true
      end

      if fourPlayerButton.highlighted then
        fourPlayerButton.pressed = true
      end

      if numberOfColumnsPlusRect.highlighted then
        numberOfColumnsPlusRect.pressed = true
      end

      if numberOfColumnsMinusRect.highlighted then
        numberOfColumnsMinusRect.pressed = true
      end

      if numberOfRowsPlusRect.highlighted then
        numberOfRowsPlusRect.pressed = true
      end

      if numberOfRowsMinusRect.highlighted then
        numberOfRowsMinusRect.pressed = true
      end

      if backButton.highlighted then
        backButton.pressed = true
      end
    end

    if sceneType == "gameplay" then
      if gameState == "playing" then
        -- check if mouse is over a card (cards highlighted flag) and set clickedCard to be that card
        for i,crd in ipairs(createdCards) do
          if crd.matched == false and crd.flipCard == false then
            if input.checkIfMouseOver(crd) then
              clickedCard = crd
            end
          end
        end
        if inGameMainMenuButton.highlighted then
          inGameMainMenuButton.pressed = true
        end
      end

      if gameState == "gameWon" then
        if tryAgainButton.highlighted then
          tryAgainButton.pressed = true
        end

        if mainMenuButton.highlighted then
          mainMenuButton.pressed = true
        end
      end

      if gameState == "gameLost" then
        if tryAgainButton.highlighted then
          tryAgainButton.pressed = true
        end

        if mainMenuButton.highlighted then
          mainMenuButton.pressed = true
        end
      end
    end
  end
end

-- helper function that checks if mouse is over target position (target.x, target.y)
function input.checkIfMouseOver(target)
  if mousePosition.x >= target.x and mousePosition.x < target.x + target.width and mousePosition.y >= target.y and mousePosition.y < target.y + target.height then
    return true
  else
    return false
  end
end

return input
