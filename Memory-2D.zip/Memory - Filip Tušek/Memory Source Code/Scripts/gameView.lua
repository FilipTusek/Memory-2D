local model = require("Scripts/gameModel")
local cards = require("Scripts/cards")
local push = require("Scripts/Plugins/push")

local graphics = {}
local view = {}

function view.draw()
  if sceneType == "mainMenu" then
    -- draw mainMenu
    graphics:setColor(buttonDefaultColor)

    graphics:drawRect(playButton.x, playButton.y, playButton.width, playButton.height, playButton.color)
    graphics:drawRect(settingsButton.x, settingsButton.y, settingsButton.width, settingsButton.height, settingsButton.color)
    graphics:drawRect(gameSetupButton.x, gameSetupButton.y, gameSetupButton.width, gameSetupButton.height, gameSetupButton.color)
    graphics:drawRect(quitButton.x, quitButton.y, quitButton.width, quitButton.height, quitButton.color)

    graphics:setColor(defaultWhiteColor)
    love.graphics.setFont(mainFont)

    love.graphics.print("Play", playButton.x + playButtonText.xOffset, playButton.y + playButtonText.yOffset)
    love.graphics.print("Settings", settingsButton.x + settingsButtonText.xOffset, settingsButton.y + settingsButtonText.yOffset)
    love.graphics.print("Game Setup", gameSetupButton.x + gameSetupButtonText.xOffset, gameSetupButton.y + gameSetupButtonText.yOffset)
    love.graphics.print("Quit", quitButton.x + quitButtonText.xOffset, quitButton.y + quitButtonText.yOffset)

    --change color of buttons if mouse is over them
    if playButton.highlighted then
      playButton.color = buttonHighlightedColor
    else
      playButton.color = buttonDefaultColor
    end

    if settingsButton.highlighted then
      settingsButton.color = buttonHighlightedColor
    else
      settingsButton.color = buttonDefaultColor
    end

    if gameSetupButton.highlighted then
      gameSetupButton.color = buttonHighlightedColor
    else
      gameSetupButton.color = buttonDefaultColor
    end

    if quitButton.highlighted then
      quitButton.color = buttonHighlightedColor
    else
      quitButton.color = buttonDefaultColor
    end
  end

  if sceneType == "settings" then
    -- draw settings screen
    volumeSlider.slider:draw()
    sfxSlider.slider:draw()

    graphics:setColor(buttonDefaultColor)

    graphics:drawRect(musicVolumeTextRect.x, musicVolumeTextRect.y, musicVolumeTextRect.width, musicVolumeTextRect.height, musicVolumeTextRect.color)
    graphics:drawRect(sfxVolumeTextRect.x, sfxVolumeTextRect.y, sfxVolumeTextRect.width, sfxVolumeTextRect.height, sfxVolumeTextRect.color)
    graphics:drawRect(backButton.x, backButton.y, backButton.width, backButton.height, backButton.color)

    graphics:setColor(defaultWhiteColor)

    love.graphics.print("Music Volume", musicVolumeTextRect.x + musicVolumeText.xOffset, musicVolumeTextRect.y + musicVolumeText.yOffset)
    love.graphics.print("SFX Volume", sfxVolumeTextRect.x + sfxVolumeText.xOffset, sfxVolumeTextRect.y + sfxVolumeText.yOffset)
    love.graphics.print("Back", backButton.x + backButtonText.xOffset, backButton.y + backButtonText.yOffset)

    --change color of buttons if mouse is over them
    if backButton.highlighted then
      backButton.color = buttonHighlightedColor
    else
      backButton.color = buttonDefaultColor
    end
  end

  if sceneType == "gameSetup" then
    -- draw game setup window
    love.graphics.setFont(mediumFont)
    graphics:setColor(buttonDefaultColor)

    graphics:drawRect(onePlayerButton.x, onePlayerButton.y, onePlayerButton.width, onePlayerButton.height, onePlayerButton.color)
    graphics:drawRect(twoPlayerButton.x, twoPlayerButton.y, twoPlayerButton.width, twoPlayerButton.height, twoPlayerButton.color)
    graphics:drawRect(threePlayerButton.x, threePlayerButton.y, threePlayerButton.width, threePlayerButton.height, threePlayerButton.color)
    graphics:drawRect(fourPlayerButton.x, fourPlayerButton.y, fourPlayerButton.width, fourPlayerButton.height, fourPlayerButton.color)

    graphics:drawRect(numberOfColumnsTextRect.x, numberOfColumnsTextRect.y, numberOfColumnsTextRect.width, numberOfColumnsTextRect.height, numberOfColumnsTextRect.color)
    graphics:drawRect(numberOfRowsTextRect.x, numberOfRowsTextRect.y, numberOfRowsTextRect.width, numberOfRowsTextRect.height, numberOfRowsTextRect.color)
    graphics:drawRect(backButton.x, backButton.y, backButton.width, backButton.height, backButton.color)

    graphics:drawRect(numberOfColumnsPlusRect.x, numberOfColumnsPlusRect.y, numberOfColumnsPlusRect.width, numberOfColumnsPlusRect.height, numberOfColumnsPlusRect.color)
    graphics:drawRect(numberOfColumnsMinusRect.x, numberOfColumnsMinusRect.y, numberOfColumnsMinusRect.width, numberOfColumnsMinusRect.height, numberOfColumnsMinusRect.color)
    graphics:drawRect(numberOfRowsPlusRect.x, numberOfRowsPlusRect.y, numberOfRowsPlusRect.width, numberOfRowsPlusRect.height, numberOfRowsPlusRect.color)
    graphics:drawRect(numberOfRowsMinusRect.x, numberOfRowsMinusRect.y, numberOfRowsMinusRect.width, numberOfRowsMinusRect.height, numberOfRowsMinusRect.color)

    graphics:setColor(defaultWhiteColor)

    love.graphics.print("Number of columns: " .. saveData.numberOfColumns, numberOfColumnsTextRect.x + numberOfColumnsText.xOffset, numberOfColumnsTextRect.y + numberOfColumnsText.yOffset)
    love.graphics.print("Number of rows : " .. saveData.numberOfRows, numberOfRowsTextRect.x + numberOfRowsText.xOffset, numberOfRowsTextRect.y + numberOfRowsText.yOffset)

    love.graphics.setFont(mainFont)

    love.graphics.print("1 Player", onePlayerButton.x + onePlayerButtonText.xOffset, onePlayerButton.y + onePlayerButtonText.yOffset)
    love.graphics.print("2 Players", twoPlayerButton.x + twoPlayerButtonText.xOffset, twoPlayerButton.y + twoPlayerButtonText.yOffset)
    love.graphics.print("3 Players", threePlayerButton.x + threePlayerButtonText.xOffset, threePlayerButton.y + threePlayerButtonText.yOffset)
    love.graphics.print("4 Players", fourPlayerButton.x + fourPlayerButtonText.xOffset, fourPlayerButton.y + fourPlayerButtonText.yOffset)

    love.graphics.print("+", numberOfColumnsPlusRect.x, numberOfColumnsPlusRect.y - 12.5)
    love.graphics.print("+", numberOfRowsPlusRect.x, numberOfRowsPlusRect.y - 12.5)
    love.graphics.print("-", numberOfColumnsMinusRect.x + 12.5, numberOfColumnsMinusRect.y - 12.5)
    love.graphics.print("-", numberOfRowsMinusRect.x + 12.5, numberOfRowsMinusRect.y - 12.5)

    love.graphics.print("Back", backButton.x + backButtonText.xOffset, backButton.y + backButtonText.yOffset)

    --change color of buttons if mouse is over them
    if onePlayerButton.highlighted then
      onePlayerButton.color = buttonHighlightedColor
    else
      onePlayerButton.color = buttonDefaultColor
    end

    if twoPlayerButton.highlighted then
      twoPlayerButton.color = buttonHighlightedColor
    else
      twoPlayerButton.color = buttonDefaultColor
    end

    if threePlayerButton.highlighted then
      threePlayerButton.color = buttonHighlightedColor
    else
      threePlayerButton.color = buttonDefaultColor
    end

    if fourPlayerButton.highlighted then
      fourPlayerButton.color = buttonHighlightedColor
    else
      fourPlayerButton.color = buttonDefaultColor
    end

    if numberOfColumnsPlusRect.highlighted then
      numberOfColumnsPlusRect.color = buttonHighlightedColor
    else
      numberOfColumnsPlusRect.color = buttonDefaultColor
    end

    if numberOfColumnsMinusRect.highlighted then
      numberOfColumnsMinusRect.color = buttonHighlightedColor
    else
      numberOfColumnsMinusRect.color = buttonDefaultColor
    end

    if numberOfRowsPlusRect.highlighted then
      numberOfRowsPlusRect.color = buttonHighlightedColor
    else
      numberOfRowsPlusRect.color = buttonDefaultColor
    end

    if numberOfRowsMinusRect.highlighted then
      numberOfRowsMinusRect.color = buttonHighlightedColor
    else
      numberOfRowsMinusRect.color = buttonDefaultColor
    end

    if backButton.highlighted then
      backButton.color = buttonHighlightedColor
    else
      backButton.color = buttonDefaultColor
    end
  end

  if sceneType == "gameplay" then
    -- draw gameplay screen
    if gameState == "playing" then
      -- if game is playing, draw everything needed for gameplay
      cards.drawCards()

      love.graphics.setFont(mainFont)

      graphics:drawRect(inGameMainMenuButton.x, inGameMainMenuButton.y, inGameMainMenuButton.width, inGameMainMenuButton.height, inGameMainMenuButton.color)

      graphics:drawRect(player1TextRect.x, player1TextRect.y, player1TextRect.width, player1TextRect.height, player1TextRect.color)

      graphics:setColor(defaultWhiteColor)
      love.graphics.print("Player 1", player1TextRect.x + player1Text.xOffset, player1TextRect.y + player1Text.yOffset)

      -- check number of players and draw correct number of player rects and texts according to the number of players
      -- rotate player rects and texts if needed
      if saveData.numberOfPlayers >= 2 then
        -- set color
        graphics:setColor(buttonDefaultColor)
        -- used to change translation and rotation of graphic elements between love.graphics.push() and love.graphic.pop()
        love.graphics.push()
        love.graphics.translate(push:getWidth()/2, push:getHeight()/2)
        love.graphics.rotate(player2TextRect.rotation)
        graphics:drawRect(player2TextRect.x, player2TextRect.y, player2TextRect.width, player2TextRect.height, player2TextRect.color)

        graphics:setColor(defaultWhiteColor)
        love.graphics.print("Player 2", player2TextRect.x + player2Text.xOffset, player2TextRect.y + player2Text.yOffset)
        love.graphics.pop()
        if saveData.numberOfPlayers >= 3 then
          graphics:setColor(buttonDefaultColor)
          love.graphics.push()
          love.graphics.translate(push:getWidth()/2, push:getHeight()/2)
          love.graphics.rotate(player3TextRect.rotation)
          graphics:drawRect(player3TextRect.x, player3TextRect.y, player3TextRect.width, player3TextRect.height, player3TextRect.color)

          graphics:setColor(defaultWhiteColor)
          love.graphics.print("Player 3", player3TextRect.x + player3Text.xOffset, player3TextRect.y + player3Text.yOffset)
          love.graphics.pop()
          if saveData.numberOfPlayers >= 4 then
            graphics:setColor(buttonDefaultColor)
            graphics:drawRect(player4TextRect.x, player4TextRect.y, player4TextRect.width, player4TextRect.height, player4TextRect.color)

            graphics:setColor(defaultWhiteColor)
            love.graphics.print("Player 4", player4TextRect.x + player4Text.xOffset, player4TextRect.y + player4Text.yOffset)
          end
        end
      end


      graphics:setColor(defaultWhiteColor)
      love.graphics.setFont(smallFont)

      love.graphics.print("Main Menu", inGameMainMenuButton.x + inGameMainMenuButtonText.xOffset, inGameMainMenuButton.y + inGameMainMenuButtonText.yOffset)

      --change color of buttons if mouse is over them
      if player1TextRect.highlighted then
        player1TextRect.color = buttonHighlightedColor
      else
        player1TextRect.color = buttonDefaultColor
      end

      if player2TextRect.highlighted then
        player2TextRect.color = buttonHighlightedColor
      else
        player2TextRect.color = buttonDefaultColor
      end

      if player3TextRect.highlighted then
        player3TextRect.color = buttonHighlightedColor
      else
        player3TextRect.color = buttonDefaultColor
      end

      if player4TextRect.highlighted then
        player4TextRect.color = buttonHighlightedColor
      else
        player4TextRect.color = buttonDefaultColor
      end

      if inGameMainMenuButton.highlighted then
        inGameMainMenuButton.color = buttonHighlightedColor
      else
        inGameMainMenuButton.color = buttonDefaultColor
      end
    end

    if gameState == "gameWon" then
      -- draw game won screen
      love.graphics.setFont(mainFont)

      graphics:setColor(buttonDefaultColor)

      graphics:drawRect(tryAgainButton.x, tryAgainButton.y, tryAgainButton.width, tryAgainButton.height, tryAgainButton.color)
      graphics:drawRect(mainMenuButton.x, mainMenuButton.y, mainMenuButton.width, mainMenuButton.height, mainMenuButton.color)

      graphics:setColor(defaultWhiteColor)

      love.graphics.print("Try Again", tryAgainButton.x + tryAgainButtonText.xOffset, tryAgainButton.y + tryAgainButtonText.yOffset)
      love.graphics.print("Main Menu", mainMenuButton.x + mainMenuButtonText.xOffset, mainMenuButton.y + mainMenuButtonText.yOffset)

      -- check for number of players and draw stuff to screen acordingly
      if saveData.numberOfPlayers == 1 then
        love.graphics.print("Congratulations, You Win!", gameWonText.x, gameWonText.y)
      end

      if saveData.numberOfPlayers > 1 then
        love.graphics.setFont(mediumFont)
        -- draw correct number of highscores to the screen
        for i = 1, saveData.numberOfPlayers do
          graphics:drawRect(highScoreRects[i].x, highScoreRects[i].y, highScoreRects[i].width, highScoreRects[i].height, buttonHighlightedColor)

          graphics:setColor(defaultWhiteColor)

          love.graphics.print(highScoreTexts[#highScoreTexts - (i + #highScoreTexts - saveData.numberOfPlayers - 1)].text, highScoreRects[i].x + highScoreTexts[#highScoreTexts - (i + #highScoreTexts - saveData.numberOfPlayers - 1)].xOffset,
           highScoreRects[i].y + highScoreTexts[#highScoreTexts - (i + #highScoreTexts - saveData.numberOfPlayers - 1)].yOffset)

           if i <= numberOfWinners then
             love.graphics.print("Winner!", highScoreRects[i].x - 200, highScoreRects[i].y)
           end
        end
      end

      --change color of buttons if mouse is over them
      if tryAgainButton.highlighted then
        tryAgainButton.color = buttonHighlightedColor
      else
        tryAgainButton.color = buttonDefaultColor
      end

      if mainMenuButton.highlighted then
        mainMenuButton.color = buttonHighlightedColor
      else
        mainMenuButton.color = buttonDefaultColor
      end
    end
  end
end

-- helper function to set color of graphics
function graphics:setColor(c)
  if self.lastcolor ~= c then
    self.lastcolor = c
    love.graphics.setColor(c)
  end
  return self
end

-- helper function to draw rects and applying color to them
function graphics:drawRect(x, y, w, h, c)
  if c then
    self:setColor(c)
  end
  love.graphics.rectangle("fill", x, y, w, h)
  return self
end

return view
