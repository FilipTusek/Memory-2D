local input = require("Scripts/inputManager")
local cards = require("Scripts/cards")

-- used for flipping cards, matching cards, etc.
firstSelectedCard = nil
secondSelectedCard = nil

local currentFirstSelectedCard = nil
local currentSecondSelectedCard = nil

local controller = {}

-- used to check if all possible matches have been made
local numberOfMatches = 0

-- used to dictate which player's turn it is
local currentPlayer = 1

function controller.update(dt)
  input.update(dt)

  if sceneType == "gameplay" then
    if gameState == "playing" then
      -- highlight rect of player which turn it is
      for i = 1, #playerTextRects do
        if i == currentPlayer then
          playerTextRects[i].highlighted = true
        else
          playerTextRects[i].highlighted = false
        end
      end

      -- if there first card is selected, flip it up
      if firstSelectedCard ~= nil then
        if firstSelectedCard.flipCard then
          cards.flipUp(dt, firstSelectedCard)
        end
      end

      -- if first card has already been selected, flip it down
      if currentFirstSelectedCard ~= nil then
        if currentFirstSelectedCard.flipCard then
          cards.flipDown(dt, currentFirstSelectedCard)
        else
          currentFirstSelectedCard = nil
        end
      end

      if secondSelectedCard ~= nil then
        if secondSelectedCard.flipCard then
          cards.flipUp(dt, secondSelectedCard)
        end
      end

      if currentSecondSelectedCard ~= nil then
        if currentSecondSelectedCard.flipCard then
          cards.flipDown(dt, currentSecondSelectedCard)
        else
          currentSecondSelectedCard = nil
        end
      end
    end
  end
end

-- callback function called every time mouse has moved
function love.mousemoved(x, y, dx, dy)
  input.mousemoved(x, y, dx, dy)
end

-- callback function called every time mouse button has been clicked
function love.mousepressed(x, y, button, isTouch)
  input.mousepressed(x, y, button, isTouch)

  if sceneType == "mainMenu" then
    -- check if button has been pressed and act acordingly(change its "pressed" flag, play clickSound and change sceneType, and/or gameState)
    -- this applies to all of the buttons in the game
    if playButton.pressed then
      playButton.pressed = false
      clickSound:play()
      sceneType = "gameplay"
      gameState = "playing"
    end

    if settingsButton.pressed then
      settingsButton.pressed = false
      clickSound:play()
      sceneType = "settings"
    end

    if gameSetupButton.pressed then
      gameSetupButton.pressed = false
      clickSound:play()
      sceneType = "gameSetup"
    end

    if quitButton.pressed then
      clickSound:play()
      love.event.quit(0)
    end
  end

  if sceneType == "settings" then
    if backButton.pressed then
      backButton.pressed = false
      clickSound:play()
      sceneType = "mainMenu"
    end
  end

  if sceneType == "gameSetup" then
    if onePlayerButton.pressed then
      onePlayerButton.pressed = false
      clickSound:play()
      saveData.numberOfPlayers = 1
    end

    if twoPlayerButton.pressed then
      twoPlayerButton.pressed = false
      clickSound:play()
      saveData.numberOfPlayers = 2
    end

    if threePlayerButton.pressed then
      threePlayerButton.pressed = false
      clickSound:play()
      saveData.numberOfPlayers = 3
    end

    if fourPlayerButton.pressed then
      fourPlayerButton.pressed = false
      clickSound:play()
      saveData.numberOfPlayers = 4
    end

    if numberOfColumnsPlusRect.pressed then
      numberOfColumnsPlusRect.pressed = false
      clickSound:play()
    -- check if there is enough card sprites so that all cards could get drawn
      if (saveData.numberOfCards + saveData.numberOfRows) / 2 <= 17 then
        -- check if there will be even number of cards
        if (saveData.numberOfColumns + 1) % 2 == 0 or saveData.numberOfRows % 2 == 0 then
          saveData.numberOfColumns = saveData.numberOfColumns + 1
          saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
        else
          -- if not, reduce number of rows by 1, if it's not 1 allready
          if saveData.numberOfRows > 1 then
            saveData.numberOfColumns = saveData.numberOfColumns + 1
            saveData.numberOfRows = saveData.numberOfRows - 1
            saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
          else
            saveData.numberOfColumns = saveData.numberOfColumns + 1
            saveData.numberOfRows = saveData.numberOfRows + 1
            saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
          end
        end
      end
    end

    if numberOfColumnsMinusRect.pressed then
      numberOfColumnsMinusRect.pressed = false
      clickSound:play()
      if saveData.numberOfColumns > 1 then
        -- check if there will be even number of cards
        if (saveData.numberOfColumns - 1) % 2 == 0 or saveData.numberOfRows % 2 == 0 then
          saveData.numberOfColumns = saveData.numberOfColumns - 1
          saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
        else
          -- if not, decrease number of columns by 2, if it's not 2 or less
          if saveData.numberOfColumns > 2 then
            saveData.numberOfColumns = saveData.numberOfColumns - 2
            saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
          end
        end
      end
    end

    if numberOfRowsPlusRect.pressed then
      numberOfRowsPlusRect.pressed = false
      clickSound:play()
      if (saveData.numberOfCards + saveData.numberOfColumns) / 2 <= 17 then
        -- check if there will be even number of cards
        if (saveData.numberOfRows + 1) % 2 == 0 or saveData.numberOfColumns % 2 == 0 then
          saveData.numberOfRows = saveData.numberOfRows + 1
          saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
        else
          -- if not, reduce number of rows by 1, if it's not 1 allready
          if saveData.numberOfColumns > 1 then
            saveData.numberOfRows = saveData.numberOfRows + 1
            saveData.numberOfColumns = saveData.numberOfColumns - 1
            saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
          else
            saveData.numberOfRows = saveData.numberOfRows + 1
            saveData.numberOfColumns = saveData.numberOfColumns + 1
            saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
          end
        end
      end
    end

    if numberOfRowsMinusRect.pressed then
      numberOfRowsMinusRect.pressed = false
      clickSound:play()
      if saveData.numberOfRows > 1 then
        -- check if there will be even number of cards
        if (saveData.numberOfRows - 1) % 2 == 0 or saveData.numberOfColumns % 2 == 0 then
          saveData.numberOfRows = saveData.numberOfRows - 1
          saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
        else
          -- if not, decrease number of columns by 2, if it's not 2 or less
          if saveData.numberOfRows > 2 then
            saveData.numberOfRows = saveData.numberOfRows - 2
            saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
          end
        end
      end
    end

    if backButton.pressed then
      backButton.pressed = false
      setCardScale()
      createdCards = {}

      for i = 1, #sprites do
        table.insert(spritesForCreation, sprites[i])
      end
      -- reload cards with new width, height and scale
      cards.loadAssets()

      clickSound:play()

      -- save new data (width, height and cardScale) so that the game can be replayed without restarting
      love.filesystem.write("data.lua", table.show(saveData, "saveData"))

      sceneType = "mainMenu"
    end
  end

  if sceneType == "gameplay" then
    if gameState == "playing" then
      --check if first card is nil and a card has been clicked
      if firstSelectedCard == nil and clickedCard ~= nil then
        -- if so, then set firstSelectedCard to card that has been clicked and set its "flipCard" flag to true
        clickSound:play()
        firstSelectedCard = clickedCard
        firstSelectedCard.flipCard = true
        clickedCard = nil
        secondSelectedCard = nil
      -- check if secondSelectedCard is nil and card has been clicked, but it's not the same card as firstSelectedCard
      elseif secondSelectedCard == nil and clickedCard ~= nil and clickedCard ~= firstSelectedCard then
        -- if so, then set secondSelectedCard to card that has been clicked and set its "flipCard" flag to true
        clickSound:play()
        secondSelectedCard = clickedCard
        secondSelectedCard.flipCard = true
        clickedCard = nil
        -- since there are 2 selected cards, check if they are a match
        -- the check is done here because player needs to get change as soon as the second card is selected and if its not a match
        if firstSelectedCard.front ~= secondSelectedCard.front then
          -- if they aren't then go to next player
          if currentPlayer < saveData.numberOfPlayers then
            currentPlayer = currentPlayer + 1
          else
            currentPlayer = 1
          end
        end
      -- check if both first and secondSelectedCard aren't nil and another card has been clicked
      elseif firstSelectedCard ~= nil and secondSelectedCard ~= nil and clickedCard ~= nil then
        -- if so and if first and secondSelectedCard weren't a match, reset them, ste their flipCard flags to true and set firstSelectedCard to be the newly clicked card
        if secondSelectedCard.front ~= firstSelectedCard.front then
          clickSound:play()

          currentFirstSelectedCard = firstSelectedCard
          currentSecondSelectedCard = secondSelectedCard

          currentFirstSelectedCard.flipCard = true
          currentSecondSelectedCard.flipCard = true

          firstSelectedCard = clickedCard
          firstSelectedCard.flipCard = true
          clickedCard = nil
          secondSelectedCard = nil
        end
      end

      -- check if both first and secondSelectedCard aren't nil and they are a match
      if firstSelectedCard ~= nil and secondSelectedCard ~= nil and firstSelectedCard.front == secondSelectedCard.front then
        -- if so, increase number of matches made, set their matched flags to true so that they can't be clicked on again, increase current player's score by 1 and reset firstSelectedCard
        matchSound:play()
        numberOfMatches = numberOfMatches + 1

        playerScores[currentPlayer] = playerScores[currentPlayer] + 1

        secondSelectedCard.flipCard = true

        firstSelectedCard.matched = true
        secondSelectedCard.matched = true

        firstSelectedCard = nil
      end

      -- check if number of matches is greater or equal to number of possible matches
      if numberOfMatches >= saveData.numberOfCards/2 then
        -- if so, reset the cards so that the game can be replayed, sort highScores so ranking can be created and change the state of the game
        cards.reset(createdCards)
        controller.sortHighScores(playerScores)

        gameState = "gameWon"
      end

      if inGameMainMenuButton.pressed then
        cards.reset(createdCards)
        inGameMainMenuButton.pressed = false
        inGameMainMenuButton.highlighted = false
        clickSound:play()
        currentPlayer = 1
        sceneType = "mainMenu"

      controller.resetPlayerScores()
      end
    end

    if gameState == "gameWon" then
      if tryAgainButton.pressed then
        clickSound:play()
        cards.reset(createdCards)
        numberOfMatches = 0
        currentPlayer = 1
        numberOfWinners = 1

        controller.resetPlayerScores()

        gameState = "playing"
        tryAgainButton.pressed = false
      end

      if mainMenuButton.pressed then
        clickSound:play()
        numberOfMatches = 0
        currentPlayer = 1
        numberOfWinners = 1

        controller.resetPlayerScores()

        sceneType = "mainMenu"
        mainMenuButton.pressed = false
      end
    end
  end
end

function controller.sortHighScores(scores)
  local highScores = {}
  local currentPlayerScores = {}
  local localPlayerNames = {}
  local scoreAdded = false

  -- populate local highScores table until it has amount of scores equal to the number of players
  for i, v in ipairs(scores) do
    if i <= saveData.numberOfPlayers then
      highScores[#highScores + 1] = v
    end
  end

 -- sort the table from lowest to highest number
  table.sort(highScores)

  -- populate local currentPlayerScores table with number of scores equal to the number of players
  -- this is used to ensure there can't be the same player score more than once (entries in this table get deleted after being used)
  for i = 1, saveData.numberOfPlayers do
    table.insert(currentPlayerScores, scores[i])
  end

  -- populate local localPlayerNames table with number of playerNames equal to the number of players
  -- this is used to ensure there can't be the same player mame more than once (entires in this table get deleted after being used)
  for i = 1, #playerNames do
    table.insert(localPlayerNames, playerNames[i])
  end

  -- match highscores to correct players (highscoreTexts with localPlayerNames)
  for i = 1, #highScores do
    scoreAdded = false
    for j = 1, #currentPlayerScores do
      -- check if currently checked highscore is equal to any of currentPlayerScores and score hasn't already been added
      if highScores[i] == currentPlayerScores[j] and scoreAdded == false then
        -- if so, then match that highscoreText with that player name
        highScoreTexts[i].text = localPlayerNames[j] .. ": " .. tostring(highScores[i])
        table.remove(currentPlayerScores, j)
        table.remove(localPlayerNames, j)
        scoreAdded = true
      end
    end
  end
  -- check if last highscore (the highest score) is equal to eny other score
  for j = 1, #highScores do
    if highScores[#highScores] == highScores[j] and #highScores ~= j then
      -- if so, increase number of winners by 1
      numberOfWinners = numberOfWinners + 1
    end
  end
end

-- helper function used to reset player scores
function controller.resetPlayerScores()
  for i = 1, #playerScores do
    playerScores[i] = 0
  end
end

-- helper function used to set card scale
function setCardScale ()
  -- card scale calculation (compensation for different number of cards, rows and columns)
  local columnToRowRatio = saveData.numberOfColumns / saveData.numberOfRows
  local rowToColumnRatio = saveData.numberOfRows / saveData.numberOfColumns

  -- set right scaling considering columnToRowRatio and rowToColumnRatio
  if saveData.numberOfColumns >= saveData.numberOfRows then
    if columnToRowRatio < 1.5 then
      cardScale = 2 - columnToRowRatio
    elseif columnToRowRatio > 2 then
      cardScale = math.sqrt(columnToRowRatio) / columnToRowRatio * 1.5
    else
      cardScale = columnToRowRatio / 2
    end
  else
    if rowToColumnRatio < 2 then
      cardScale = 2 - rowToColumnRatio
    elseif rowToColumnRatio > 2 then
      cardScale = math.sqrt(rowToColumnRatio) / rowToColumnRatio / 1.5
    else
      cardScale = rowToColumnRatio / 4
    end
  end
end

return controller
