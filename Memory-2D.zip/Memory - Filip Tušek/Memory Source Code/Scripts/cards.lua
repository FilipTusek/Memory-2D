local model = require("Scripts/gameModel")
local push = require("Scripts/Plugins/push")

createdCards = {}

local card = {}

local cards = {}

local cardFlipSpeed = 7.5

local initialCardX
local initialCardY

local countHorizontal = 1

function cards.create(card)
  math.randomseed(love.timer.getTime())

  -- create cards depending on number of rows and number of columns
  -- make sure cards come in pairs and add cards to createdCards table with their corresponding values (x, y, width, height, etc.)
  for i = 1, saveData.numberOfRows * saveData.numberOfColumns / 2 do
    local range = love.math.newRandomGenerator()
    local r = range:random(1, #spritesForCreation)
    table.insert(createdCards, {x = card.x, y = card.y, back = card.back, front = spritesForCreation[r], width = spritesForCreation[r]:getWidth() * cardScale,
    height = spritesForCreation[r]:getHeight() * cardScale, matched = card.matched, scaleX = card.scaleX, scaleY = card.scaleY,
     flipped = card.flipped, flipCard = card.flipCard})
    table.insert(createdCards, {x = card.x, y = card.y, back = card.back, front = spritesForCreation[r], width = spritesForCreation[r]:getWidth() * cardScale,
    height = spritesForCreation[r]:getHeight() * cardScale, matched = card.matched, scaleX = card.scaleX, scaleY = card.scaleY,
     flipped = card.flipped, flipCard = card.flipCard})
    table.remove(spritesForCreation, r)
  end
  cards.shuffle(createdCards)
end

-- randomly mix cards so that the pattern they are arranged in won't be the same twice
function cards.shuffle(createdCards)
  for i = 1, #createdCards do
    math.randomseed(love.timer.getTime())
    local r = math.random(i, #createdCards)
    local ci = createdCards[i]
    local cr = createdCards[r]
    createdCards[r] = ci
    createdCards[i] = cr
  end
end

-- reset firts and secondSelectedCard as well as data for each created card and turn them face down
function cards.reset(createdCards)
  firstSelectedCard = nil
  secondSelectedCard = nil

  for i = 1, #createdCards do
    createdCards[i].x = initialCardX
    createdCards[i].matched = false
    createdCards[i].pressed = false
    createdCards[i].highlighted = false
    createdCards[i].flipped = false
    createdCards[i].flipCard = false

    cards.turnCardDown(createdCards[i])
  end

  cards.shuffle(createdCards)
end

-- load card data
function cards.loadAssets()
  card.back = nil
  card.front = nil
  card.width = nil
  card.height = nil
  card.scaleX = cardScale
  card.scaleY = cardScale
  card.matched = false
  card.highlighted = false
  card.color = cardDefaultColor
  card.flipCard = false
  card.flipped = false

  setInitialCardPosition()

  card.x = initialCardX
  card.y = initialCardY

  card.back = love.graphics.newImage("Sprites/Cards/cardBack_blue5.png")
  cards.create(card)
end

-- helper function that draws cards to screen
function cards.drawCards()
  local spaceX = initialCardX
  local spaceY = initialCardY

  -- check if each card in createdCards table is matched or not, if it is highlighted or not, draw it on its right position and set its color acordingly
  for i, crd in ipairs(createdCards) do
    if crd.matched == false and crd.back ~= crd.front then
      if crd.highlighted then
        love.graphics.setColor(cardHighlightedColor)
      else
        love.graphics.setColor(defaultWhiteColor)
      end
    else
      love.graphics.setColor(defaultWhiteColor)
    end

    -- make sure rows and columns are properly filled with cards
    if countHorizontal < saveData.numberOfColumns then
      love.graphics.draw(crd.back, crd.x, crd.y, nil, crd.scaleX, crd.scaleY)
      spaceX = spaceX + crd.width + 5 * cardScale
      crd.x = spaceX
      crd.y = spaceY
      countHorizontal = countHorizontal + 1
    else
      love.graphics.draw(crd.back, crd.x, crd.y, nil, crd.scaleX, crd.scaleY)
      crd.y = spaceY
      spaceY = spaceY + crd.height + 5 * cardScale
      countHorizontal = 1
      spaceX = initialCardX
    end
  end
  love.graphics.setColor(defaultWhiteColor)
end

-- helper function that flips card up ("animation")
function cards.flipUp(dt, card)
  local originalCardScaleX = cardScale

  -- shrink or enlarge card so it appears to be flipping
  -- scale is used to "animate" cards because of lack of spritesheets for proper animation
  if card.flipped == false then
    if card.scaleX > 0 then
      card.scaleX = card.scaleX - dt * (cardFlipSpeed * cardScale)
    else
      card.flipped = true
      cards.turnCardUp(card)
    end
  else
    if card.scaleX < originalCardScaleX then
      card.scaleX = card.scaleX + dt * (cardFlipSpeed * cardScale)
    else
      card.flipCard = false
      card.scaleX = originalCardScaleX
    end
  end
end

-- helper function that flips card down ("animation")
function cards.flipDown(dt, card)
  local originalCardScaleX = cardScale

  if card.flipped then
    if card.scaleX > 0 then
      card.scaleX = card.scaleX - dt * (cardFlipSpeed * cardScale)
    else
      card.flipped = false
      cards.turnCardDown(card)
    end
  else
    if card.scaleX < originalCardScaleX then
      card.scaleX = card.scaleX + dt * (cardFlipSpeed * cardScale)
    else
      card.flipCard = false
      card.scaleX = originalCardScaleX
    end
  end
end

-- helper function that turns card up (draws card's front image instead of card's back image)
function cards.turnCardUp(card)
  card.back = card.front
end

-- helper function that turns card down (draws card's back image instead of card's front image)
function cards.turnCardDown(card)
  card.back = love.graphics.newImage("Sprites/Cards/cardBack_blue5.png")
end

-- helper function that sets initial card position taking scale into consideration
function setInitialCardPosition()
  initialCardX = push:getWidth() / 2 - saveData.numberOfColumns * sprites[2]:getWidth() * cardScale / 2
  initialCardY = push:getHeight() / 2 - saveData.numberOfRows * sprites[2]:getHeight() * cardScale / 2
end

return cards
