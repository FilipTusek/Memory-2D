local push = require("Scripts/Plugins/push")
local slider = require("Scripts/Plugins/simple-slider")

local model = {}

function model.load()
  -- game fonts (sizes)
  mainFont = love.graphics.newFont(60)
  mediumFont = love.graphics.newFont(40)
  smallFont = love.graphics.newFont(30)

-- used for saving data
  saveData = {}
    saveData.musicVolume = 0.25
    saveData.sfxVolume = 0.25
    saveData.numberOfColumns = 8
    saveData.numberOfRows = 4
    saveData.numberOfCards = saveData.numberOfRows * saveData.numberOfColumns
    saveData.numberOfPlayers = 1

-- check if save exists, if so, load it
  if love.filesystem.exists("data.lua") then
    local data = love.filesystem.load("data.lua")
    data()
  end

  cardScale = 1

  setCardScale()

-- sounds and music
  backgroundMusic = love.audio.newSource("Music/BackgroundMusic.mp3")
  matchSound = love.audio.newSource("SFX/CoinPickup.wav")
  clickSound = love.audio.newSource("SFX/click1.ogg")

  backgroundMusic:setVolume(saveData.musicVolume)
  matchSound:setVolume(saveData.sfxVolume)
  clickSound:setVolume(saveData.sfxVolume)

  backgroundMusic:setLooping(true)

  backgroundMusic:play()

-- used to keep track of player scores and for creating ranking
playerScores = {
   0,
   0,
   0,
   0
}

-- used to match scores with correct player and showing player name with player score
-- also can used so that players can input their names instead of just player1-4
playerNames = {
  "Player1",
  "Player2",
  "Player3",
  "Player4"
}

-- used to determain if there are more players with same hihghscore
numberOfWinners = 1

-- colors
  defaultWhiteColor = {255, 255, 255}
  buttonDefaultColor = {150, 150, 150}
  buttonHighlightedColor = {0, 50, 100}
  cardHighlightedColor = {0, 100, 150}

-- card sprites
  sprites = {
    love.graphics.newImage("Sprites/Cards/cardClubsA.png"),
    love.graphics.newImage("Sprites/Cards/cardClubsK.png"),
    love.graphics.newImage("Sprites/Cards/cardClubsQ.png"),
    love.graphics.newImage("Sprites/Cards/cardClubsJ.png"),
    love.graphics.newImage("Sprites/Cards/cardDiamondsA.png"),
    love.graphics.newImage("Sprites/Cards/cardDiamondsK.png"),
    love.graphics.newImage("Sprites/Cards/cardDiamondsQ.png"),
    love.graphics.newImage("Sprites/Cards/cardDiamondsJ.png"),
    love.graphics.newImage("Sprites/Cards/cardHeartsA.png"),
    love.graphics.newImage("Sprites/Cards/cardHeartsK.png"),
    love.graphics.newImage("Sprites/Cards/cardHeartsQ.png"),
    love.graphics.newImage("Sprites/Cards/cardHeartsJ.png"),
    love.graphics.newImage("Sprites/Cards/cardSpadesA.png"),
    love.graphics.newImage("Sprites/Cards/cardSpadesK.png"),
    love.graphics.newImage("Sprites/Cards/cardSpadesQ.png"),
    love.graphics.newImage("Sprites/Cards/cardSpadesJ.png"),
    love.graphics.newImage("Sprites/Cards/cardJoker.png")
  }

-- table of sprites used for card creation. When cards are created, each sprite gets deleted from the list so that there can't be double pairs.
-- This table is needed so it could be repopulated when replaying the game with different settings (number of cards)
  spritesForCreation = {}

  for i = 1, #sprites do
    table.insert(spritesForCreation, sprites[i])
  end

-- all textRect tables are used to set information about position, width, height and color of rects that are drawn behind text so it would be easeier to read

-- mainMenu visuals
  playButton = {}
    playButton.width = 300
    playButton.height = 100
    playButton.xOffset = -150
    playButton.yOffset = -450
    playButton.x = push:getWidth()/2 + playButton.xOffset
    playButton.y = push:getHeight()/2 + playButton.yOffset
    playButton.color = buttonDefaultColor
    playButton.highlighted = false
    playButton.pressed = false

  playButtonText = {}
    playButtonText.xOffset = 85
    playButtonText.yOffset = 15

  settingsButton = {}
    settingsButton.width = 300
    settingsButton.height = 100
    settingsButton.xOffset = -150
    settingsButton.yOffset = -200
    settingsButton.x = push:getWidth()/2 + settingsButton.xOffset
    settingsButton.y = push:getHeight()/2 + settingsButton.yOffset
    settingsButton.color = buttonDefaultColor
    settingsButton.highlighted = false
    settingsButton.pressed = false

  settingsButtonText = {}
    settingsButtonText.xOffset = 30
    settingsButtonText.yOffset = 15

  gameSetupButton = {}
    gameSetupButton.width = 400
    gameSetupButton.height = 100
    gameSetupButton.xOffset = -200
    gameSetupButton.yOffset = 50
    gameSetupButton.x = push:getWidth()/2 + gameSetupButton.xOffset
    gameSetupButton.y = push:getHeight()/2 + gameSetupButton.yOffset
    gameSetupButton.color = buttonDefaultColor
    gameSetupButton.highlighted = false
    gameSetupButton.pressed = false

  gameSetupButtonText = {}
    gameSetupButtonText.xOffset = 15
    gameSetupButtonText.yOffset = 15

  quitButton = {}
    quitButton.width = 300
    quitButton.height = 100
    quitButton.xOffset = -150
    quitButton.yOffset = 300
    quitButton.x = push:getWidth()/2 + quitButton.xOffset
    quitButton.y = push:getHeight()/2 + quitButton.yOffset
    quitButton.color = buttonDefaultColor
    quitButton.highlighted = false
    quitButton.pressed = false

  quitButtonText = {}
    quitButtonText.xOffset = 85
    quitButtonText.yOffset = 15

-- settings visuals
  volumeSlider = {}
    volumeSlider.xOffset = 0
    volumeSlider.yOffset = -300
    volumeSlider.x = push:getWidth()/2 + volumeSlider.xOffset
    volumeSlider.y = push:getHeight()/2 + volumeSlider.yOffset
    volumeSlider.length = 450
    volumeSlider.slider = newSlider(volumeSlider.x, volumeSlider.y, volumeSlider.length, saveData.musicVolume, 0, 1,
    -- function that controlls music volume based on slider position and saves that value
    -- saving can be implemented on exiting settings window, but for the sake of simplicity and keeping everything in one place I decided to keep this here,
    -- since performance is not realy an issue with this simple game
    function (v)
      saveData.musicVolume = v
      love.filesystem.write("data.lua", table.show(saveData, "saveData"))
      backgroundMusic:setVolume(saveData.musicVolume)
    end)

  musicVolumeTextRect = {}
    musicVolumeTextRect.width = 500
    musicVolumeTextRect.height = 100
    musicVolumeTextRect.xOffset = -250
    musicVolumeTextRect.yOffset = -450
    musicVolumeTextRect.x = push:getWidth()/2 + musicVolumeTextRect.xOffset
    musicVolumeTextRect.y = push:getHeight()/2 + musicVolumeTextRect.yOffset
    musicVolumeTextRect.color = buttonDefaultColor

  musicVolumeText = {}
    musicVolumeText.xOffset = 45
    musicVolumeText.yOffset = 15

  sfxSlider = {}
    sfxSlider.xOffset = 0
    sfxSlider.yOffset = 0
    sfxSlider.x = push:getWidth()/2 + sfxSlider.xOffset
    sfxSlider.y = push:getHeight()/2 + sfxSlider.yOffset
    sfxSlider.length = 450
    sfxSlider.slider = newSlider(sfxSlider.x, sfxSlider.y, sfxSlider.length, saveData.sfxVolume, 0, 1,
    -- same function as in "volumeSlider"
    function (v)
      saveData.sfxVolume = v
      love.filesystem.write("data.lua", table.show(saveData, "saveData"))
      clickSound:setVolume(saveData.sfxVolume)
      matchSound:setVolume(saveData.sfxVolume)
    end)

  sfxVolumeTextRect = {}
    sfxVolumeTextRect.width = 450
    sfxVolumeTextRect.height = 100
    sfxVolumeTextRect.xOffset = -225
    sfxVolumeTextRect.yOffset = -150
    sfxVolumeTextRect.x = push:getWidth()/2 + sfxVolumeTextRect.xOffset
    sfxVolumeTextRect.y = push:getHeight()/2 + sfxVolumeTextRect.yOffset
    sfxVolumeTextRect.color = buttonDefaultColor

  sfxVolumeText = {}
    sfxVolumeText.xOffset = 50
    sfxVolumeText.yOffset = 15

  backButton = {}
    backButton.width = 250
    backButton.height = 100
    backButton.xOffset = -125
    backButton.yOffset = 350
    backButton.x = push:getWidth()/2 + backButton.xOffset
    backButton.y = push:getHeight()/2 + backButton.yOffset
    backButton.color = buttonDefaultColor
    backButton.highlighted = false
    backButton.pressed = false

  backButtonText = {}
    backButtonText.xOffset = 57
    backButtonText.yOffset = 15

-- gameSetup visuals
  onePlayerButton = {}
    onePlayerButton.width = 400
    onePlayerButton.height = 100
    onePlayerButton.xOffset = -450
    onePlayerButton.yOffset = -350
    onePlayerButton.x = push:getWidth()/2 + onePlayerButton.xOffset
    onePlayerButton.y = push:getHeight()/2 + onePlayerButton.yOffset
    onePlayerButton.color = buttonDefaultColor
    onePlayerButton.highlighted = false
    onePlayerButton.pressed = false

  onePlayerButtonText = {}
    onePlayerButtonText.xOffset = 80
    onePlayerButtonText.yOffset = 15

  twoPlayerButton = {}
    twoPlayerButton.width = 400
    twoPlayerButton.height = 100
    twoPlayerButton.xOffset = 50
    twoPlayerButton.yOffset = -350
    twoPlayerButton.x = push:getWidth()/2 + twoPlayerButton.xOffset
    twoPlayerButton.y = push:getHeight()/2 + twoPlayerButton.yOffset
    twoPlayerButton.color = buttonDefaultColor
    twoPlayerButton.highlighted = false
    twoPlayerButton.pressed = false

  twoPlayerButtonText = {}
    twoPlayerButtonText.xOffset = 60
    twoPlayerButtonText.yOffset = 15

    threePlayerButton = {}
      threePlayerButton.width = 400
      threePlayerButton.height = 100
      threePlayerButton.xOffset = -450
      threePlayerButton.yOffset = -150
      threePlayerButton.x = push:getWidth()/2 + threePlayerButton.xOffset
      threePlayerButton.y = push:getHeight()/2 + threePlayerButton.yOffset
      threePlayerButton.color = buttonDefaultColor
      threePlayerButton.highlighted = false
      threePlayerButton.pressed = false

  threePlayerButtonText = {}
    threePlayerButtonText.xOffset = 60
    threePlayerButtonText.yOffset = 15

  fourPlayerButton = {}
    fourPlayerButton.width = 400
    fourPlayerButton.height = 100
    fourPlayerButton.xOffset = 50
    fourPlayerButton.yOffset = -150
    fourPlayerButton.x = push:getWidth()/2 + fourPlayerButton.xOffset
    fourPlayerButton.y = push:getHeight()/2 + fourPlayerButton.yOffset
    fourPlayerButton.color = buttonDefaultColor
    fourPlayerButton.highlighted = false
    fourPlayerButton.pressed = false

  fourPlayerButtonText = {}
    fourPlayerButtonText.xOffset = 60
    fourPlayerButtonText.yOffset = 15

  numberOfRowsTextRect = {}
    numberOfRowsTextRect.width = 500
    numberOfRowsTextRect.height = 75
    numberOfRowsTextRect.xOffset = 200
    numberOfRowsTextRect.yOffset = 150
    numberOfRowsTextRect.x = push:getWidth()/2 + numberOfRowsTextRect.xOffset
    numberOfRowsTextRect.y = push:getHeight()/2 + numberOfRowsTextRect.yOffset
    numberOfRowsTextRect.color = buttonDefaultColor

  numberOfRowsPlusRect = {}
    numberOfRowsPlusRect.width = 50
    numberOfRowsPlusRect.height = 50
    numberOfRowsPlusRect.xOffset = 550
    numberOfRowsPlusRect.yOffset = 15
    numberOfRowsPlusRect.x = numberOfRowsTextRect.x + numberOfRowsPlusRect.xOffset
    numberOfRowsPlusRect.y = numberOfRowsTextRect.y + numberOfRowsPlusRect.yOffset
    numberOfRowsPlusRect.color = buttonDefaultColor
    numberOfRowsPlusRect.highlighted = false
    numberOfRowsPlusRect.pressed = false

  numberOfRowsMinusRect = {}
    numberOfRowsMinusRect.width = 50
    numberOfRowsMinusRect.height = 50
    numberOfRowsMinusRect.xOffset = -100
    numberOfRowsMinusRect.yOffset = 15
    numberOfRowsMinusRect.x = numberOfRowsTextRect.x + numberOfRowsMinusRect.xOffset
    numberOfRowsMinusRect.y = numberOfRowsTextRect.y + numberOfRowsMinusRect.yOffset
    numberOfRowsMinusRect.color = buttonDefaultColor
    numberOfRowsMinusRect.highlighted = false
    numberOfRowsMinusRect.pressed = false

  numberOfRowsText = {}
    numberOfRowsText.xOffset = 65
    numberOfRowsText.yOffset = 15

  numberOfColumnsTextRect = {}
    numberOfColumnsTextRect.width = 500
    numberOfColumnsTextRect.height = 75
    numberOfColumnsTextRect.xOffset = -700
    numberOfColumnsTextRect.yOffset = 150
    numberOfColumnsTextRect.x = push:getWidth()/2 + numberOfColumnsTextRect.xOffset
    numberOfColumnsTextRect.y = push:getHeight()/2 + numberOfColumnsTextRect.yOffset
    numberOfColumnsTextRect.color = buttonDefaultColor

  numberOfColumnsPlusRect = {}
    numberOfColumnsPlusRect.width = 50
    numberOfColumnsPlusRect.height = 50
    numberOfColumnsPlusRect.xOffset = 550
    numberOfColumnsPlusRect.yOffset = 15
    numberOfColumnsPlusRect.x = numberOfColumnsTextRect.x + numberOfColumnsPlusRect.xOffset
    numberOfColumnsPlusRect.y = numberOfColumnsTextRect.y + numberOfColumnsPlusRect.yOffset
    numberOfColumnsPlusRect.color = buttonDefaultColor
    numberOfColumnsPlusRect.highlighted = false
    numberOfColumnsPlusRect.pressed = false

  numberOfColumnsMinusRect = {}
    numberOfColumnsMinusRect.width = 50
    numberOfColumnsMinusRect.height = 50
    numberOfColumnsMinusRect.xOffset = -100
    numberOfColumnsMinusRect.yOffset = 15
    numberOfColumnsMinusRect.x = numberOfColumnsTextRect.x + numberOfColumnsMinusRect.xOffset
    numberOfColumnsMinusRect.y = numberOfColumnsTextRect.y + numberOfColumnsMinusRect.yOffset
    numberOfColumnsMinusRect.color = buttonDefaultColor
    numberOfColumnsMinusRect.highlighted = false
    numberOfColumnsMinusRect.pressed = false

  numberOfColumnsText = {}
    numberOfColumnsText.xOffset = 30
    numberOfColumnsText.yOffset = 15

-- gameplay visuals
  gameWonText = {}
    gameWonText.xOffset = -375
    gameWonText.yOffset = -400
    gameWonText.x = push:getWidth()/2 + gameWonText.xOffset
    gameWonText.y = push:getHeight()/2 + gameWonText.yOffset

  tryAgainButton = {}
    tryAgainButton.width = 400
    tryAgainButton.height = 100
    tryAgainButton.xOffset = -200
    tryAgainButton.yOffset = 100
    tryAgainButton.x = push:getWidth()/2 + tryAgainButton.xOffset
    tryAgainButton.y = push:getHeight()/2 + tryAgainButton.yOffset
    tryAgainButton.color = buttonDefaultColor
    tryAgainButton.highlighted = false
    tryAgainButton.pressed = false

  tryAgainButtonText = {}
    tryAgainButtonText.xOffset = 65
    tryAgainButtonText.yOffset = 15

  mainMenuButton = {}
    mainMenuButton.width = 400
    mainMenuButton.height = 100
    mainMenuButton.xOffset = -200
    mainMenuButton.yOffset = 250
    mainMenuButton.x = push:getWidth()/2 + mainMenuButton.xOffset
    mainMenuButton.y = push:getHeight()/2 + mainMenuButton.yOffset
    mainMenuButton.color = buttonDefaultColor
    mainMenuButton.highlighted = false
    mainMenuButton.pressed = false

  mainMenuButtonText = {}
    mainMenuButtonText.xOffset = 45
    mainMenuButtonText.yOffset = 15

  inGameMainMenuButton = {}
    inGameMainMenuButton.width = 200
    inGameMainMenuButton.height = 50
    inGameMainMenuButton.xOffset = 600
    inGameMainMenuButton.yOffset = -500
    inGameMainMenuButton.x = push:getWidth()/2 + inGameMainMenuButton.xOffset
    inGameMainMenuButton.y = push:getHeight()/2 + inGameMainMenuButton.yOffset
    inGameMainMenuButton.color = buttonDefaultColor
    inGameMainMenuButton.highlighted = false
    inGameMainMenuButton.pressed = false

  player1TextRect = {}
    player1TextRect.width = 300
    player1TextRect.height = 75
    player1TextRect.xOffset = -150
    player1TextRect.yOffset = 415
    player1TextRect.x = push:getWidth()/2 + player1TextRect.xOffset
    player1TextRect.y = push:getHeight()/2 + player1TextRect.yOffset
    player1TextRect.color = buttonDefaultColor
    player1TextRect.highlighted = false
    player1TextRect.rotation = 0

  player1Text = {}
    player1Text.xOffset = 30
    player1Text.yOffset = 0

  player2TextRect = {}
    player2TextRect.width = 300
    player2TextRect.height = 75
    player2TextRect.xOffset = -1115
    player2TextRect.yOffset = 200
    player2TextRect.x = push:getWidth()/2 + player2TextRect.xOffset
    player2TextRect.y = push:getHeight()/2 + player2TextRect.yOffset
    player2TextRect.color = buttonDefaultColor
    player2TextRect.highlighted = false
    player2TextRect.rotation = math.pi/2

  player2Text = {}
    player2Text.xOffset = 30
    player2Text.yOffset = 0

  player3TextRect = {}
    player3TextRect.width = 300
    player3TextRect.height = 75
    player3TextRect.xOffset = -1115
    player3TextRect.yOffset = 200
    player3TextRect.x = push:getWidth()/2 + player3TextRect.xOffset
    player3TextRect.y = push:getHeight()/2 + player3TextRect.yOffset
    player3TextRect.color = buttonDefaultColor
    player3TextRect.highlighted = false
    player3TextRect.rotation = 3*math.pi/2

  player3Text = {}
    player3Text.xOffset = 30
    player3Text.yOffset = 0

  player4TextRect = {}
    player4TextRect.width = 300
    player4TextRect.height = 75
    player4TextRect.xOffset = -150
    player4TextRect.yOffset = -475
    player4TextRect.x = push:getWidth()/2 + player4TextRect.xOffset
    player4TextRect.y = push:getHeight()/2 + player4TextRect.yOffset
    player4TextRect.color = buttonDefaultColor
    player4TextRect.highlighted = false
    player4TextRect.rotation = 0

  player4Text = {}
    player4Text.xOffset = 30
    player4Text.yOffset = 0

-- used to enable drawing the same number of textRects as the number of players (3 players, 3 textRects)
  playerTextRects = {}
  table.insert(playerTextRects, player1TextRect)
  table.insert(playerTextRects, player2TextRect)
  table.insert(playerTextRects, player3TextRect)
  table.insert(playerTextRects, player4TextRect)

  highScore1TextRect = {}
    highScore1TextRect.width = 300
    highScore1TextRect.height = 75
    highScore1TextRect.xOffset = -150
    highScore1TextRect.yOffset = -400
    highScore1TextRect.x = push:getWidth()/2 + highScore1TextRect.xOffset
    highScore1TextRect.y = push:getHeight()/2 + highScore1TextRect.yOffset

  highScore1Text = {}
    highScore1Text.xOffset = 50
    highScore1Text.yOffset = 15
    highScore1Text.text = "Enter Name"

  highScore2TextRect = {}
    highScore2TextRect.width = 300
    highScore2TextRect.height = 75
    highScore2TextRect.xOffset = -150
    highScore2TextRect.yOffset = -300
    highScore2TextRect.x = push:getWidth()/2 + highScore2TextRect.xOffset
    highScore2TextRect.y = push:getHeight()/2 + highScore2TextRect.yOffset

  highScore2Text = {}
    highScore2Text.xOffset = 50
    highScore2Text.yOffset = 15
    highScore2Text.text = "Enter Name"

  highScore3TextRect = {}
    highScore3TextRect.width = 300
    highScore3TextRect.height = 75
    highScore3TextRect.xOffset = -150
    highScore3TextRect.yOffset = -200
    highScore3TextRect.x = push:getWidth()/2 + highScore3TextRect.xOffset
    highScore3TextRect.y = push:getHeight()/2 + highScore3TextRect.yOffset

  highScore3Text = {}
    highScore3Text.xOffset = 50
    highScore3Text.yOffset = 15
    highScore3Text.text = "Enter Name"

  highScore4TextRect = {}
    highScore4TextRect.width = 300
    highScore4TextRect.height = 75
    highScore4TextRect.xOffset = -150
    highScore4TextRect.yOffset = -100
    highScore4TextRect.x = push:getWidth()/2 + highScore4TextRect.xOffset
    highScore4TextRect.y = push:getHeight()/2 + highScore4TextRect.yOffset

  highScore4Text = {}
    highScore4Text.xOffset = 50
    highScore4Text.yOffset = 15
    highScore4Text.text = "Enter Name"

-- used to enable drawing the same number of scoreRects as the nuzmber of players
  highScoreRects = {}
  table.insert(highScoreRects, highScore1TextRect)
  table.insert(highScoreRects, highScore2TextRect)
  table.insert(highScoreRects, highScore3TextRect)
  table.insert(highScoreRects, highScore4TextRect)

-- same as for "highScoreRects"
  highScoreTexts = {}
    table.insert(highScoreTexts, highScore1Text)
    table.insert(highScoreTexts, highScore2Text)
    table.insert(highScoreTexts, highScore3Text)
    table.insert(highScoreTexts, highScore4Text)

  inGameMainMenuButtonText = {}
    inGameMainMenuButtonText.xOffset = 20
    inGameMainMenuButtonText.yOffset = 7.5
  end
  
  return model
