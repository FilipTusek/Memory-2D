local push = require("Scripts/Plugins/push")
local view = require("Scripts/gameView")
local model = require("Scripts/gameModel")
local cards = require("Scripts/cards")
local controller = require("Scripts/gameController")

gameState = "playing"                     -- playing, gameWon, gameLost
sceneType = "mainMenu"                    -- mainMenu, settings, gameplay

local windowWidth, windowHeight = love.window.getDesktopDimensions()

love.window.setMode(1920, 1080)

-- enables screen resizing
push:setupScreen(1920, 1080, windowWidth, windowHeight, {fullscreen = true, resizable = true})

function love.load()
  model.load()
  cards.loadAssets()
end

function love.update(dt)
  controller.update(dt)
end

function love.draw()
  -- start applying push plugin settings (resizing the screen)
  push:start()
    view.draw()
  -- stop applying push plugin settings
  push:finish()
end

-- used for testing purposes
--[[
function love.keypressed(key, scancode, isrepeat)
  if key == "escape" then
    love.event.quit(0)
  end
end
]]
